import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.*;

public class ProblemB {
    public boolean forcevectors(int n) throws FileNotFoundException,IllegalArgumentException{
        int x=0,y=0,z=0,m=0,p=0,q=0;
        File file = new File("C:\\Users\\alaah\\IdeaProjects\\LabAssigment1\\src\\testcases.txt");
        Scanner sc = new Scanner(file);
        if (n<=0)
        {
            throw new IllegalArgumentException("Cannot work with n<=0");
        }
        while(n-- >= 1) {
            m = Integer.parseInt(sc.next());
            p = Integer.parseInt(sc.next());
            q = Integer.parseInt(sc.next());
            x += m;
            y += p;
            z += q;
        }
        if(x == 0 && y == 0 && z == 0){
            System.out.print("Correct");
            return true; }
        else{
            System.out.print("Not Correct");
            return false; }

}
}

