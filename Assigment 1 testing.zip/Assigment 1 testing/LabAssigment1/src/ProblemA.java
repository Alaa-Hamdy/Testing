
public class ProblemA {
    public boolean weightcheck(int weight) {
        boolean confirm;
        if (weight <= 0) {
            throw new IllegalArgumentException("Weight is not accepted");
        } else if (weight % 2 == 0 && weight != 2) {
            confirm = true;
            return confirm;
        } else {
            confirm = false;
            return confirm;
        }
    }
}