import org.junit.Test;

import static org.junit.Assert.*;

public class ProblemATest {

    @Test
    public void Evenweight1() {
        ProblemA tester = new ProblemA();
        assertEquals(true,tester.weightcheck(8));
    }
    @Test
    public void Evenweight2() {
        ProblemA tester = new ProblemA();
        assertEquals(true,tester.weightcheck(20000));
    }
    @Test
    public void Evenweight3() {
        ProblemA tester = new ProblemA();
        assertEquals(true,tester.weightcheck(60));
    }

    @Test
    public void Oddweight1() {
        ProblemA tester = new ProblemA();
        assertEquals(false,tester.weightcheck(7));
    }
    @Test
    public void Oddweight2() {
        ProblemA tester = new ProblemA();
        assertEquals(false,tester.weightcheck(7317));
    }
    @Test
    public void Oddweight3() {
        ProblemA tester = new ProblemA();
        assertEquals(false, tester.weightcheck(1));
    }
    @Test
    public void Twoweight() {
        ProblemA tester = new ProblemA();
        assertEquals(false,tester.weightcheck(2));
    }
    @Test
    public void Negativeweight()
    { ProblemA tester = new ProblemA();
        assertThrows(IllegalArgumentException.class , () -> {
            tester.weightcheck(-8); }); }
}