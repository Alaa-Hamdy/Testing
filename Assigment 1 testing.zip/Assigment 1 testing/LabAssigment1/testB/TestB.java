
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.FileNotFoundException;

public class TestB {
    @Test
    public void test8() throws FileNotFoundException,IllegalArgumentException {
        ProblemB solver = new ProblemB();
        assertThrows(IllegalArgumentException.class, () -> {
            solver.forcevectors(-10);
        });
    }
}
